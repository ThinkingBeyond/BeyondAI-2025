Pretrained model
